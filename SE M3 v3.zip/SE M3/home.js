 function openLogin() {
    window.location = ('./login.html')
}

