function openA() {
    window.location.href = ('./open.html')
}
function closeA() {
    window.location.href = ('./close.html')
}
function creditC() {
    window.location.href = ('./credit.html')
}
function loanL() {
    window.location.href = ('./loan.html')
}
function bTransaction() {
    window.location.href = ('./btransaction.html')
}
function cTransaction() {
    window.location.href = ('./ctransaction.html')
}
function pointsP() {
    window.location.href = ('./points.html')
}
function billsB() {
    window.location.href = ('./bills.html')
}
function transferT() {
    window.location.href = ('./transfer.html')
}
function reminderR() {
    window.location.href = ('./reminder.html')
}
function paymentP() {
    window.location.href = ('./payment.html')
}
function reportR() {
    window.location.href = ('./report.html')
}
function notifyN() {
    window.location.href = ('./notify.html')
}
