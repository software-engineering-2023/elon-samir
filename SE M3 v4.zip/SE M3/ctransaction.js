function popUp(){
    let ccnum = document.getElementById('ccnum')

    if(ccnum.value == ""){
      alert("Please enter a credit card number");
    }
    else{
      
    }
  }