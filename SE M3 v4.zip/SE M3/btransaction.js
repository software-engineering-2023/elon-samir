function popUp(){
    let accnum = document.getElementById('accnum')

    if(accnum.value == ""){
      alert("Please enter a number");
    }
    else{
      
    }
  }