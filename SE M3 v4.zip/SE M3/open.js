function popUp() {
    alert("Account created successfully!");
  }