document.getElementById('login').addEventListener('submit', function(event) {
    window.location = ('./login.html')
  });